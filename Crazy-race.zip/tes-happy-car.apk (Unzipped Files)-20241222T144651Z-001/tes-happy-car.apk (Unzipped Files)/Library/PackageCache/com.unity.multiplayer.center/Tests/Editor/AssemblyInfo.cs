using System.Runtime.CompilerServices;

[assembly:InternalsVisibleTo("Unity.Multiplayer.Center.GettingStartedTab.Tests")]
